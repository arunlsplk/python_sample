import uuid


def generate_random_id():
    # Generate a random UUID (Version 4) and return it as a string
    return str(uuid.uuid4())
